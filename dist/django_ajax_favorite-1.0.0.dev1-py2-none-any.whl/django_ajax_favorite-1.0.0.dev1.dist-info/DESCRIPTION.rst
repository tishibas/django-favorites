In addition like, vote, thumbs up  and follow functionalities are also supported


